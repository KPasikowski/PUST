clear all

Upp = 2;
Ypp = 0.8;
U_min = 1.2;
U_max = 2.8;
dU_max = 0.25;

Kk = 1600;
Tp = 0.5;